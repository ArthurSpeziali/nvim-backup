source ~/.config/nvim/settings.vim
source ~/.config/nvim/keys/mappings.vim
" source ~/.config/nvim/projectist.vim
source ~/.config/nvim/vim-plug/plugins.vim
" luafile ~/.config/nvim/lua/lsp/elixir-lsp.lua

luafile ~/.config/nvim/lua/autopairs.lua
luafile ~/.config/nvim/lua/plugins/dap.lua
luafile ~/.config/nvim/lua/lsp/haskell-lsp.lua


autocmd FileType eelixir setlocal commentstring=<!--\ %s\ -->

" Carrega configurações LUA
lua require('plugins.compe-config')
lua require('plugins.mason')
lua require('lsp')  -- Agora carrega o arquivo lua/lsp.lua

colorscheme tokyonight

autocmd BufReadPost *.ex set shiftwidth=2
autocmd BufReadPost *.heex set shiftwidth=2

" let g:pymode_lint_checker = 'flake8'
" let g:pymode_lint_options = '--ignore=W'

" autocmd TabNewEntered * silent! %bwipeout!

let g:NERDTreeDirArrowExpandable="+"
let g:NERDTreeDirArrowCollapsible="~"

" air-line
let g:airline_powerline_fonts = 1

if !exists('g:airline_symbols')
    let g:airline_symbols = {}
endif

"unicode symbols
let g:airline_left_sep = '»'
let g:airline_left_sep = '▶'
let g:airline_right_sep = '«'
let g:airline_right_sep = '◀'
let g:airline_symbols.linenr = '␊'
let g:airline_symbols.linenr = '␤'
let g:airline_symbols.linenr = '¶'
let g:airline_symbols.branch = '⎇'
let g:airline_symbols.paste = 'ρ'
let g:airline_symbols.paste = 'Þ'
let g:airline_symbols.paste = '∥'
let g:airline_symbols.whitespace = 'Ξ'
" airline symbols                                                                                                                              
let g:airline_left_sep = ''
let g:airline_left_alt_sep = ''
let g:airline_right_sep = ''
let g:airline_right_alt_sep = ''
let g:airline_symbols.branch = ''
let g:airline_symbols.readonly = ''
let g:airline_symbols.linenr = ''

let g:WebDevIconsUnicodeDecorateFolderNodes = 1
let g:WebDevIconsUnicodeDecorateFolderNodeDefaultSymbol = ''

let g:WebDevIconsUnicodeDecorateFileNodesExtensionSymbols = {}
let g:WebDevIconsUnicodeDecorateFileNodesExtensionSymbols['nerdtree'] = ''



" Apagar depois


"if has('nvim')
 " Plug 'Shougo/deoplete.nvim', { 'do': ':UpdateRemotePlugins' }
" else
  " Plug 'Shougo/deoplete.nvim'
  " Plug 'roxma/nvim-yarp'
  " Plug 'roxma/vim-hug-neovim-rpc'
" endif
" let g:deoplete#enable_at_startup = 1

" let g:alchemist_tag_disable = 1
"
" " Evitar conflito com o tab do Copilot
let g:copilot_no_tab_map = v:true

" Mapear Ctrl+X para aceitar sugestão
inoremap <silent><expr> <C-c> copilot#Accept("\<CR>")

" Configurar LSP normalmente
set completeopt=menuone,noselect



" Auto pairs bugado para fdechar }
" inoremap } }<C-g>


let g:projectionist_heuristics = {
\   "lib/*_web/live/": {
\     "*_live.ex": {
\       "alternate": "{}_live.html.heex",
\       "type": "source"
\     },
\     "*_live.html.heex": {
\       "alternate": "{}_live.ex",
\       "type": "template"
\     }
\   },
\   "mix.exs": {
\     "lib/*.ex": {
\       "alternate": "test/{}_test.exs",
\       "type": "source"
\     },
\     "test/*_test.exs": {
\       "alternate": "lib/{}.ex",
\       "type": "test"
\     }
\   }
\}
