let g:projectionist_heuristics = {
\   "mix.exs": {
\     "test/*_test.exs": {"alternate": "lib/{}.ex", "type": "test"},
\     "lib/**/*.ex": {"alternate": "test/{}_test.exs", "type": "source"},
\     "lib/**/*_web/live/*.ex": {"alternate": "lib/**/*_web/live/*.html.heex", "type": "source"},
\     "lib/**/*_web/live/*.html.heex": {"alternate": "lib/**/*_web/live/*.ex", "type": "source"}
\   }
\ }
