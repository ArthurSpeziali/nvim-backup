" Use alt + hjkl to resize windows
nnoremap <M-j>        :resize -2<CR>
nnoremap <M-k>        :resize +2<CR>
nnoremap <M-h>        :vertical resize -2<CR>
nnoremap <M-l>        :vertical resize +2<CR>

" Transitar de tela
inoremap <S-Tab> <Esc><C-w>wi

nnoremap <C-n> :NERDTreeToggle<cr>

nnoremap <M-Esc> :nohlsearch<CR>


inoremap <C-a> <C-x><C-o>

" EASY CAPS - SHIFT + u = UPPER CASE, u = lower case
" inoremap <c-u> <ESC>viwUi
" nnoremap <c-u> viwU<Esc>

" save and exit easier way 

inoremap <C-s> <Esc>:w<CR>i
nnoremap <C-s> :w<CR>
inoremap <C-q> <esc>:wqa!<cr>                             " save and exit
nnoremap <C-q> :wqa!<cr>
inoremap <C-d> <esc>:q!<cr>                             " save and exit
nnoremap <C-d> :q!<cr>

inoremap ;; <Esc>

" Better tabbing
" vnoremap < <gv
" vnoremap < >gv

" Better window navigation
nnoremap <C-h> <C-w>h
nnoremap <C-j> <C-w>j
nnoremap <C-k> <C-w>k
nnoremap <C-l> <C-w>l

" Open nerdTree with keyshortcut
let mapleader = ","

" TABS
noremap <Tab> :tabnext<CR>
noremap <S-Tab> :tabprevious<CR>
nnoremap <C-b> :tabnew<CR>


" No more Arrow keys, deal with it
" noremap <Up> <NOP>
" noremap <Down> <NOP>
" noremap <Left> <NOP>
" noremap <Right> <NOP>
" noremap <S>k <NOP>

"inoremap <C-f> <Esc>cc<cr>i


" Opens a new terminal in vertical split
" noremap <Leader>t :sp | resize -3 | term://bash<CR>

" Comment lines
" xmap <M-.> gc<CR>

"Search for all ocourrences of the phrase that you write
" nnoremap <C-f> :lua require('telescope.builtin').grep_string({ search = vim.fn.input("Grep For > ") })<CR>

" CTRL + C now yank the selected
vmap <C-c> "+y

" Clears the vim highlighing
" noremap <C-l> :noh<CR>

" Changes all ocourrences for the text that you have typed

nnoremap <Leader>r :%s///g<Left><Left>
nnoremap <Leader>rc :%s///gc<Left><Left><Left>

xnoremap <Leader>r :s///g<Left><Left>
xnoremap <Leader>rc :s///gc<Left><Left><Left>

vnoremap * y/\V<C-R>=escape(@",'/\')<CR><CR>

"Debugging keys

" Keys for completion
" inoremap <silent><expr> <C-Space> compe#complete()
" inoremap <silent><expr> <C-e>         compe#close('<C-e>')

nnoremap µ :cnext<CR>
nnoremap ” :cprevious<CR> 

nnoremap <Leader>! :tabmove 0<CR>
nnoremap <Leader>@ :tabmove 1<CR>
nnoremap <Leader># :tabmove 2<CR>
nnoremap <Leader>$ :tabmove 3<CR>
nnoremap <Leader>% :tabmove 4<CR>
nnoremap <Leader>y :tabmove 5<CR>
nnoremap <Leader>& :tabmove 6<CR>
nnoremap <Leader>* :tabmove 7<CR>
nnoremap <Leader>( :tabmove 8<CR>
nnoremap <Leader>) :tabmove 9<CR>

nnoremap <Leader>1 1gt<CR>
nnoremap <Leader>2 2gt<CR>
nnoremap <Leader>3 3gt<CR>
nnoremap <Leader>4 4gt<CR>
nnoremap <Leader>5 5gt<CR>
nnoremap <Leader>6 6gt<CR>
nnoremap <Leader>7 7gt<CR>
nnoremap <Leader>8 8gt<CR>
nnoremap <Leader>9 9gt<CR>

nnoremap <Leader>- :tabfirst<CR>
nnoremap <Leader>= :tablast<CR>


" Próximo Error
nnoremap ]e :lua vim.diagnostic.goto_next({severity = vim.diagnostic.severity.ERROR})<CR>
" Anterior Error
nnoremap [e :lua vim.diagnostic.goto_prev({severity = vim.diagnostic.severity.ERROR})<CR>

" Próximo Warning
nnoremap ]w :lua vim.diagnostic.goto_next({severity = vim.diagnostic.severity.WARN})<CR>
" Anterior Warning
nnoremap [w :lua vim.diagnostic.goto_prev({severity = vim.diagnostic.severity.WARN})<CR>

" Próximo Hint
nnoremap ]h :lua vim.diagnostic.goto_next({severity = vim.diagnostic.severity.HINT})<CR>
" Anterior Hint
nnoremap [h :lua vim.diagnostic.goto_prev({severity = vim.diagnostic.severity.HINT})<CR>

" Envia diagnósticos para quickfix
nnoremap <leader>q :lua vim.diagnostic.setqflist()<CR>


nnoremap <C-l> :A<CR>
" nnoremap <C-o> :b#<CR>
nnoremap <C-M-x> :bufdo bd!<CR>

nnoremap <C-g> :Telescope find_files<CR>
nnoremap <C-f> :Telescope live_grep<CR>
