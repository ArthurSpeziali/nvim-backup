local npairs = require('nvim-autopairs')

npairs.setup({
    check_ts = true,          -- integração com treesitter
    enable_moveright = true,  -- pula automaticamente se próximo for par
    disable_filetype = { "TelescopePrompt", "vim" }, -- desativa em certos arquivos
    map_cr = true,             -- Enter cria nova linha entre pares
    map_bs = true,             -- Backspace remove par automaticamente
})

-- npairs.setup({
--     enable_moveright = true,
-- })

-- -- regra customizada para permitir duplicar }
-- local Rule = require('nvim-autopairs.rule')
-- npairs.add_rules {
--     Rule("}", "}", "lua")
--         :with_move(function(opts)
--             return false  -- false = não pular automaticamente
--         end)
-- }

