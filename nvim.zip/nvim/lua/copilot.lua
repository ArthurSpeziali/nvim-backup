local copilot = require('lspconfig')

copilot.setup({
  panel = { enabled = true },         -- Painel do Copilot
  suggestion = {
    enabled = true,
    auto_trigger = true,
    keymap = {
      -- accept = "<C-a>",
      -- prev = "<C-]>",
      -- next = "<C-[>",
      -- dismiss = "<C-x>",
    },
  },
})

