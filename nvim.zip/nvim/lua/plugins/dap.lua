local dap = require("dap")
local dapui = require("dapui")

-- Configuração para Go
-- require("dap-go").setup()

-- UI bonita
dapui.setup()

-- Abrir/fechar a UI automaticamente
dap.listeners.after.event_initialized["dapui_config"] = function()
  dapui.open()
end
dap.listeners.before.event_terminated["dapui_config"] = function()
  dapui.close()
end
dap.listeners.before.event_exited["dapui_config"] = function()
  dapui.close()
end

vim.keymap.set("n", "<F5>", function() require("dap").continue() end)
vim.keymap.set("n", "<F9>", function() require("dap").step_over() end)
vim.keymap.set("n", "<F10>", function() require("dap").step_into() end)
vim.keymap.set("n", "<F12>", function() require("dap").step_out() end)
vim.keymap.set("n", "<Leader>b", function() require("dap").toggle_breakpoint() end)
vim.keymap.set("n", "<Leader>dr", function() require("dap").repl.open() end)
vim.keymap.set("n", "<Leader>dl", function() require("dap").run_last() end)


vim.fn.sign_define('DapBreakpoint', {text='🛑', texthl='', linehl='', numhl=''})
vim.fn.sign_define('DapStopped', {text='➡️', texthl='', linehl='', numhl=''})

dapui.setup({
    layouts = {
        {
            -- Janela lateral apenas com variáveis
            elements = {
                { id = "scopes", size = 1.0 },  -- mostra todas as variáveis do escopo
            },
            size = 40,          -- largura da sidebar
            position = "right", -- pode ser "left" ou "right"
        },
        {
            -- Janela inferior só com os controles de passo
            elements = {
                { id = "repl", size = 1.0 },  -- opcional, você pode tirar se não quiser REPL
            },
            size = 10,          -- altura da janela inferior
            position = "bottom",
        },
    },
    controls = {
        enabled = true,     -- habilita os botões de step
        element = "repl",   -- pode associar os controles à janela inferior
    },
})
