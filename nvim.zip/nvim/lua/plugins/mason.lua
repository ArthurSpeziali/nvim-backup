-- mason.lua
require('mason').setup({
  ui = {
    icons = {
      package_installed = "✓",
      package_pending = "➜",
      package_uninstalled = "✗"
    }
  }
})

require('mason-lspconfig').setup({
  ensure_installed = { 'elixirls', 'html', 'cssls', 'rust_analyzer' },
  automatic_installation = true, -- Instala automaticamente os LSPs configurados
})

-- Opcional: Configuração para nvim-lspconfig usar Mason
local lspconfig = require('lspconfig')
local mason_lspconfig = require('mason-lspconfig')

-- mason_lspconfig.setup_handlers({
--   -- Configuração padrão para todos os LSPs
--   function(server_name)
--     lspconfig[server_name].setup({
--       capabilities = require('cmp_nvim_lsp').default_capabilities(),
--     })
--   end,
--   -- Configurações específicas podem ser adicionadas aqui
--   ['elixirls'] = function()
--     lspconfig.elixirls.setup({
--       cmd = { "/home/arthur/bin/elixir-ls" },
--       settings = {
--         elixirLS = {
--           dialyzerEnabled = true,
--           fetchDeps = false,
--           enableTestLenses = true,
--           suggestSpecs = true,
--           format = { enabled = true, dotFormatter = ".formatter.exs" }
--         }
--       }
--     })
--   end,
-- })
