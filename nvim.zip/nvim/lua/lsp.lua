local lspconfig = require('lspconfig')
local cmp_nvim_lsp = require('cmp_nvim_lsp')

vim.filetype.add({
  extension = {
    sface = "surface",
    templ = "html",
  }
})

vim.api.nvim_create_autocmd("BufWritePre", {
  pattern = { "*.ex", "*.exs" },
  callback = function(args)
    vim.lsp.buf.format({
      bufnr = args.buf,
      async = false,
    })
  end,
})

local capabilities = cmp_nvim_lsp.default_capabilities()

-- Configuração do ElixirLS
-- lspconfig.elixirls.setup {
--   cmd = { "/home/arthur/bin/elixir-ls" },
--   filetypes = { "elixir", "eex", "heex", "eelixir" },
--   capabilities = capabilities,
--   settings = {
--     elixirLS = {
--       dialyzerEnabled = true,
--       fetchDeps = false,
--       enableTestLenses = true,
--       suggestSpecs = true,
--       format = {
--         enabled = true,
--         dotFormatter = ".formatter.exs"
--       }
--     }
--   },
--   on_attach = function(client, bufnr)
--     -- Formatação automática ao salvar
--     vim.api.nvim_create_autocmd('BufWritePre', {
--       buffer = bufnr,
--       callback = function()
--         vim.lsp.buf.format({ async = false })
--       end
--     })
    
--     -- Mapeamentos LSP
--     local opts = { noremap = true, silent = true, buffer = bufnr }
--     vim.keymap.set('n', 'gd', vim.lsp.buf.definition, opts)
--     vim.keymap.set('n', 'K', vim.lsp.buf.hover, opts)
--     vim.keymap.set('n', 'gr', vim.lsp.buf.references, opts)
--     vim.keymap.set('n', '<leader>rn', vim.lsp.buf.rename, opts)
--   end
-- }

-- Configuração para arquivos HEEx
-- vim.filetype.add({
--   extension = {
--     heex = "heex",
--     eex = "eex"
--   }
-- })

-- Configuração geral do LSP
local on_attach = function(client, bufnr)
    -- Habilita completion triggered by <c-x><c-o>
    vim.api.nvim_buf_set_option(bufnr, 'omnifunc', 'v:lua.vim.lsp.omnifunc')
end

-- Configuração para múltiplos servidores LSP
-- local servers = { 'elixir-ls' }

-- for _, lsp in pairs(servers) do
--     require('lspconfig')[lsp].setup {
--         on_attach = on_attach,
--     }
-- end
