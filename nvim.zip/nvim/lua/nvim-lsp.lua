local cmp = require'cmp'
vim.opt.clipboard = "unnamedplus"

cmp.setup({
  snippet = {
    expand = function(args)
      require('luasnip').lsp_expand(args.body)
    end,
  },
  mapping = cmp.mapping.preset.insert({
    ['<C-b>'] = cmp.mapping.scroll_docs(-4),
    ['<C-f>'] = cmp.mapping.scroll_docs(4),
    ['<C-Space>'] = cmp.mapping.complete(),
    ['<C-e>'] = cmp.mapping.abort(),
    ['<CR>'] = cmp.mapping.confirm({ select = true }),
  }),
  sources = cmp.config.sources({
    { name = 'nvim_lsp' },
    { name = 'luasnip' },
  }, {
    { name = 'buffer' },
    { name = 'path' },
  })
})
-- treesitter.lua
require('nvim-treesitter.configs').setup({
  ensure_installed = { 'elixir', 'heex', 'javascript', 'typescript', 'lua', 'vim' },
  highlight = {
    enable = true,
    additional_vim_regex_highlighting = false,
  },
  indent = {
    enable = true,
  },
})

-- trouble.lua (crie este arquivo)
require('trouble').setup({
  auto_open = false,
  auto_close = true,
  use_diagnostic_signs = true
})

-- Mapeamento para abrir/fechar lista de erros
vim.keymap.set('n', '<leader>xx', '<cmd>TroubleToggle<cr>', { desc = 'Toggle Trouble' })
vim.keymap.set('n', '<leader>xw', '<cmd>TroubleToggle workspace_diagnostics<cr>', { desc = 'Workspace Diagnostics' })
vim.keymap.set('n', '<leader>xd', '<cmd>TroubleToggle document_diagnostics<cr>', { desc = 'Document Diagnostics' })


-- local lspconfig = require('lspconfig')

-- Configuração específica do ElixirLS
-- lspconfig.elixirls.setup({
--     cmd = { vim.fn.expand("$HOME/.local/share/nvim/mason/packages/elixir-ls/elixir-ls") },
--     settings = {
--         elixirLS = {
--             dialyzerEnabled = true,
--             fetchDeps = false,
--             enableTestLenses = false,
--             suggestSpecs = false,
--         }
--     },
--     on_attach = function(client, bufnr)
--         -- Atalhos úteis
--         local opts = { noremap = true, silent = true, buffer = bufnr }
        
--         vim.keymap.set('n', 'gd', vim.lsp.buf.definition, opts)
--         vim.keymap.set('n', 'K', vim.lsp.buf.hover, opts)
--         vim.keymap.set('n', 'gi', vim.lsp.buf.implementation, opts)
--         vim.keymap.set('n', '<leader>rn', vim.lsp.buf.rename, opts)
--         vim.keymap.set('n', '<leader>ca', vim.lsp.buf.code_action, opts)
--         vim.keymap.set('n', 'gr', vim.lasp.buf.references, opts)
--     end
-- })

