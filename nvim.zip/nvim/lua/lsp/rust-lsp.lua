local lspconfig = require('lspconfig')
lspconfig.rust_analyzer.setup({
    -- Configurações específicas para o Rust Analyzer
    -- Consulte a documentação para mais opções: https://github.com/rust-analyzer/rust-analyzer/blob/main/docs/user/generated_config.adoc
    settings = {
        ["rust-analyzer"] = {
            -- Configurações específicas do Rust Analyzer
            -- Por exemplo, habilitar autocompletar, formatação, etc.
            -- Veja a documentação para todas as opções disponíveis
            completions = {
                enable = true,
            },
            -- Outras configurações aqui...
        }
    }
})

-- Configuração para autocompletar
vim.cmd([[autocmd Filetype rust setlocal omnifunc=v:lua.vim.lsp.omnifunc]])
