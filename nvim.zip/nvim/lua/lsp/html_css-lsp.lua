local lspconfig = require('lspconfig')
local cmp_nvim_lsp = require('cmp_nvim_lsp')

local capabilities = cmp_nvim_lsp.default_capabilities()

-- HTML LSP
lspconfig.html.setup{
    filetypes = {"html", "heex"},
    capabilities = capabilities,
}

-- CSS LSP
lspconfig.cssls.setup{
    capabilities = capabilities,
}

