vim.api.nvim_exec([[
    autocmd FileType typescript setlocal ts=2 sts=2 sw=2 expandtab
    autocmd FileType javascript setlocal ts=2 sts=2 sw=2 expandtab

    require'lspconfig'.tsserver.setup{}
]], true)
