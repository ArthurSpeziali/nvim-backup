require'lspconfig'.pyright.setup{}

vim.g.pymode_python = 'python3'
vim.g.pymode_options = 0
vim.g.pymode_lint_on_write = 0
