local lspconfig = vim.lsp.config
local capabilities = require("cmp_nvim_lsp").default_capabilities()

-- Keymaps LSP
local on_attach = function(client, bufnr)
  local opts = { noremap=true, silent=true, buffer=bufnr }
  local keymap = vim.keymap.set

  keymap("n", "gd", vim.lsp.buf.definition, opts)
  keymap("n", "K", vim.lsp.buf.hover, opts)
  keymap("n", "<leader>rn", vim.lsp.buf.rename, opts)
  keymap("n", "<leader>ca", vim.lsp.buf.code_action, opts)
  keymap("n", "gr", vim.lsp.buf.references, opts)
  keymap("n", "[d", vim.diagnostic.goto_prev, opts)
  keymap("n", "]d", vim.diagnostic.goto_next, opts)

  -- Destacar simbolos iguais sob o cursor
  if client.server_capabilities.documentHighlightProvider then
    vim.api.nvim_create_autocmd({"CursorHold", "CursorHoldI"}, {
      buffer = bufnr,
      callback = vim.lsp.buf.document_highlight,
    })
    vim.api.nvim_create_autocmd({"CursorMoved", "CursorMovedI"}, {
      buffer = bufnr,
      callback = vim.lsp.buf.clear_references,
    })
  end

  -- Format on save (se o LSP suportar)
  -- if client.server_capabilities.documentFormattingProvider then
  --   vim.api.nvim_create_autocmd("BufWritePre", {
  --     buffer = bufnr,
  --     pattern = "*.ex,*.exs",
  --     callback = function()
  --       vim.lsp.buf.format({ async = false })
  --     end,
  --   })
  -- end

  -- vim.api.nvim_create_autocmd("BufWritePre", {
  -- pattern = "*.ex,*.exs",
  -- callback = function()
  --   vim.lsp.buf.format({ async = false })
  -- end,
-- })

end

-- ElixirLS
lspconfig.elixirls.setup {
  cmd = { "elixir-ls" }, -- mason já instala o binário
  capabilities = capabilities,
  on_attach = on_attach,
}

vim.diagnostic.config({
  virtual_text = true, -- mostra erro inline
  signs = true,
  underline = true,
  update_in_insert = false,
  severity_sort = true,
})

-- require('lint').linters_by_ft = {
--   elixir = {'credo'}
-- }

-- vim.api.nvim_create_autocmd({ "BufWritePost" }, {
--   callback = function()
--     require("lint").try_lint()
--   end,
-- })

vim.api.nvim_create_autocmd({ "BufWritePost" }, {
  pattern = "*.ex,*.exs",
  callback = function()
    require("lint").try_lint()
  end,
})

