vim.lsp.config("hls", {
  cmd = { "haskell-language-server-wrapper", "--lsp" },
  filetypes = { "haskell", "lhaskell" },
  root_dir = vim.fs.dirname(vim.fs.find({"*.cabal","stack.yaml","cabal.project","package.yaml","hie.yaml"}, { upward = true })[1]),
  capabilities = capabilities,  -- <- ESSENCIAL
  settings = {
    haskell = { formattingProvider = "ormolu" },
  },
})
vim.lsp.enable("hls")
