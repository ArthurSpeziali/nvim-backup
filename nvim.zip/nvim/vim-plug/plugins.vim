" auto-install vim-plug
" =============================================================================
" Plugin Manager Setup
" =============================================================================
"
filetype off

" Install the plugin manager if it doesn't exist
let s:plugin_manager=expand('~/.vim/autoload/plug.vim')
let s:plugin_url='https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim'

if empty(glob(s:plugin_manager))
  echom 'vim-plug not found. Installing...'
  if executable('curl')
    silent exec '!curl -fLo ' . s:plugin_manager . ' --create-dirs ' .
          \ s:plugin_url
  elseif executable('wget')
    call mkdir(fnamemodify(s:plugin_manager, ':h'), 'p')
    silent exec '!wget --force-directories --no-check-certificate -O ' .
          \ expand(s:plugin_manager) . ' ' . s:plugin_url
  else
    echom 'Could not download plugin manager. No plugins were installed.'
    finish
  endif
  augroup vimplug
    autocmd!
    autocmd VimEnter * PlugInstall
  augroup END
endif

call plug#begin('~/.config/nvim/autoload/plugged')
  " TEMAS
  Plug 'folke/tokyonight.nvim', { 'branch': 'main' }

Plug 'mfussenegger/nvim-dap'
Plug 'leoluz/nvim-dap-go'
Plug 'rcarriga/nvim-dap-ui'
Plug 'nvim-neotest/nvim-nio'

  Plug 'nanotee/sqls.nvim'
Plug 'folke/trouble.nvim'
  Plug 'nvim-treesitter/nvim-treesitter', {'do': ':TSUpdate'} " Essential!
Plug 'williamboman/mason.nvim'        " Gerenciador de LSPs
Plug 'williamboman/mason-lspconfig.nvim' " Bridge Mason-LSP
  " Plug 'elixir-lsp/elixir_sense'

  " Plug 'elixir-editors/vim-elixirls'

 " Plug 'elixir-tools/elixir-tools.nvim', { 'do': ':ElixirToolsInstall' }

  Plug 'preservim/nerdtree'
 
  Plug 'tpope/vim-obsession', { 'branch': 'master' }

" Plug 'prabirshrestha/vim-lsp'

  " Copilot plugin
  Plug 'github/copilot.vim'

  " Plug 'GrzegorzKozub/vim-elixirls', { 'do': ':ElixirLsCompileSync' }

  Plug 'tpope/vim-commentary'

  Plug 'iamcco/markdown-preview.nvim', { 'do': { -> mkdp#util#install() }, 'for': ['markdown', 'vim-plug'] }

  Plug 'hrsh7th/nvim-cmp'
  Plug 'hrsh7th/cmp-nvim-lsp'
  Plug 'hrsh7th/cmp-buffer'
  Plug 'hrsh7th/cmp-path'
  Plug 'L3MON4D3/LuaSnip'
  Plug 'saadparwaiz1/cmp_luasnip'
  
  Plug 'sheerun/vim-polyglot'

  Plug 'junegunn/vim-plug'
  Plug 'windwp/nvim-autopairs'

  Plug 'neovim/nvim-lspconfig'
  
  Plug 'vim-airline/vim-airline'

  Plug 'vim-airline/vim-airline-themes'

  Plug 'nvim-lua/lsp-status.nvim'

  Plug 'Xuyuanp/nerdtree-git-plugin'

  Plug 'tpope/vim-fugitive'

  Plug 'https://github.com/ryanoasis/vim-devicons'
  set encoding=UTF-8

  Plug 'nvim-lua/plenary.nvim'

  Plug 'nvim-lua/popup.nvim'

  " Plug 'hrsh7th/vim-vsnip'

  " Plug 'hrsh7th/vim-vsnip-integ'
  
  Plug 'tpope/vim-projectionist'
  
  Plug 'c-brenn/fuzzy-projectionist.vim'
 Plug 'nvim-telescope/telescope.nvim', {'do': ':UpdateRemotePlugins'} 

  Plug 'mhinz/vim-mix-format'

  Plug 'mfussenegger/nvim-lint'

call plug#end()
