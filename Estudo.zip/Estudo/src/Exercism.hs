module Exercism where 

import Data.Fixed

e1 :: Float -> Fixed E2
e1 r = realToFrac (pi * r ^ (2 :: Int))

e2 :: Float -> Fixed E2 
e2 r = realToFrac (2 * pi * r)

e3 :: Float -> Float -> Fixed E2 
e3 a b = realToFrac (sqrt $ a*a + b*b)

e4 :: Float -> Float -> Fixed E2
e4 r1 r2 = realToFrac $ (e1 r1) - (e1 r2)
