module Help where  

fruta :: String -> String 
fruta x = "Deliciosa " <> x
