-- Hello World em Haskell 
module Main where 
import Text.Printf (printf)
-- import Help (fruta)
-- import Data.Function ((&))

-- quadrado :: Int -> Int
-- quadrado x = x * x 

-- triplica :: Int -> Int 
-- triplica x = x * 3 

-- polinomio :: Int -> Int 
-- polinomio x = x ^ (2 :: Int) + 10 * x + 2

-- soma :: Float -> Float -> Float 
-- soma x y = x + y

main :: IO ()
main = do 
  printf "Hello World!\n"
